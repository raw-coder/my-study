######################################
# 2. Descriptive Statistics
#####################################
# Line execution: Ctrl+Enter
# 컴퓨터에서의 한영 변환: Shift+Alt


demo(graphics)
demo(persp)


######################################
# p14...R을 이용한 시각화(plot)
#######################################
ls()
rm(list=ls())

install.packages("mlbench")
library(mlbench)
data(Ozone)
#?data

Ozone
fix(Ozone)
View(Ozone)
head(Ozone)
tail(Ozone)
str(Ozone)
dim(Ozone)

plot(x=Ozone$V8, y=Ozone$V9,
     xlab="Sandvurg Temp",
     ylab="El Monte Temp",
     main="Ozone",
     pch=21,
     cex=0.5,
     col="red",
     xlim=?(0,100), ylim=c(0,90))
#?plot
######################################
# p15...R을 이용한 시각화(lines)
######################################

#data(cars)
fix(cars)

plot(cars,
     xlim=c(-10, 25),
     ylim=c(-10, 120))
abline(a=-0.5, b=3.5, col="red")
abline(h=60, lty="dashed")
abline(v = 15, lty = "dashed")
points(x=c(5, 10), y=c(80, 100), 
       pch="*", col="red", cex=3)
# ?points


######################################
# p16...R을 이용한 시각화 (barplot)
######################################
cars<-c(1, 3, 6, 4, 9)
cars
class(cars)
trucks<-c(2, 5, 4, 5, 12)
suvs<-c(4, 4, 6, 6, 16)
autos_data<-cbind(cars, trucks, suvs)
autos_data
fix(autos_data)

rownames(autos_data)<-c("Mon", "Tue", "Wed", "Thu", "Fri")
autos_data

barplot(cars)
barplot(autos_data)
barplot(autos_data, main="Cars", xlab="Days", ylab="Total")
barplot(autos_data, main="Autos", ylab="Total", beside=TRUE)
?barplot

######################################
# p18...R을 이용한 시각화 (pie)
######################################
pie(cars, labels=c("Mon", "Tue", "Wed", "Thu", "Fri"))
pie(cars, 
    labels=c("Mon", "Tue", "Wed", "Thu", "Fri"), 
    col=c("red", "orange", "yellow", "green", "blue"))

######################################
# p19...R을 이용한 시각화 (histogram)
######################################
autos<-c(1, 3, 6, 4, 9, 2, 5, 4, 5, 12, 4, 4, 6, 6, 16)
hist(autos, col="orange")
hist(autos, prob=TRUE, col="lightblue")

######################################
# p20...R을 이용한 시각화 (boxplot)
######################################
boxplot(autos, col = "lightgray")

fix(InsectSprays)
boxplot(count ~ spray, data = InsectSprays, col = "lightgray")
?boxplot

######################################
# p21...측도를 이용한 자료의 정리
###### 중심위치의 측도 ##############
######################################
iris
fix(iris)
iris_SL <- iris$Sepal.Length
length(iris_SL)

sample(length(iris_SL), 10)
iris_SL[sample(length(iris_SL), 10)] <- NA
iris_SL

mean(iris_SL, na.rm = TRUE)
# ?mean

median(iris_SL, na.rm = T)

table(iris_SL)
# ?table
which.max( table(iris_SL) )


######################################
# p22...측도를 이용한 자료의 정리
###### 산포의측도 ##############
######################################
var(iris_SL, na.rm = T)
sd(iris_SL, na.rm = T)
range(iris_SL, na.rm = T)
IQR(iris_SL, na.rm = T)
?IQR
min(iris_SL, na.rm = T)
max(iris_SL, na.rm = T)
quantile(iris_SL,na.rm = T)

######################################
# p23...측도를 이용한 자료의 정리
###### 분포형태의 측도 ##############
######################################

install.packages("e1071")
library(e1071)

skewness(iris_SL, na.rm=T)
kurtosis(iris_SL, na.rm=T)

? skewness


######################################
# p24...R에서 자료의 요약을 보여주는 기타 함수
#
######################################
summary(iris_SL)
head(iris_SL)
tail(iris_SL)
str(iris)
# ?str


######################################
##### End of 2. 기술통계(descriptive Stat)
####################################






















######################################
# 3. Probabiltiy Distribution Function(분포함수)
#####################################
rm(list=ls())

##############################
## Example 
################################
#p33 
x<-c(1,2,3,4)
px<-c(1/8,1/8,1/2)
1-sum(px)
px<-c(1/8,1/8,1/2, 0.25)
px

mean_x=sum(x*px)
mean_x

var_x=sum((x-mean_x)^2*px)
var_x

######################################
# p52...R 실습 : 정규분포
####################################
mu <- 3; sigma <- 2  
x <- 2.5
dnorm(x, mu, sigma) # density (pdf) 
pnorm(x, mu, sigma) # distribution function (cdf)
p <- 0.3
qnorm(p, mu, sigma) # quantile function
qnorm( 0.95, 0, 1 )
qnorm( 0.025, 0, 1 )

?dnorm
?pnorm
?qnorm

#################################
######### Example  ##############
################################
#p53...
mu<-175; sigma<-3

#1)
1-pnorm(177,mu,sigma)

#2)
qnorm(0.2,mu,sigma)

#####################################
######### Example  ################
#####################################
#p54...

#1)
p1<-pnorm(-1.64,0,1)
#method1
2*p1
#method2
p2<-pnorm(1.64,0,1,lower.tail = FALSE)
p1+p2

#2)
qnorm( 0.95, 0, 1 )

#3)
pnorm(5,3,2)-pnorm(2,3,2)

######################################
# p62...R 실습 ... t, 카이제곱, F 분포
####################################
pchisq( 2, df=3 )
qchisq( 0.95, df=5 )
dt( -1, df=10 )

# ?rt
rt( 10, df=10 ) # Pseudo-Random Number Generation From T-Distribution

# ?df
df( 3, df1=5, df2=7 )
pf( 3, df1=5, df2=7 )
qf( 0.10, df1=5, df2=7 )

#################################
########### Example  ############
################################
#p84 
data1<-c(260,265,250,270,272,258,262,268,270,252)
t.test(data1)
# ? t.test
# t.test(data1, conf.level = 0.95)

# function
# confint<-function(x,sigma=-1,alpha=0.05)
# {
#   n<-length(x)
#   xb<-mean(x)
#   if(sigma>=0)
#   {
#     tmp<-sigma/sqrt(n)*qnorm(1-alpha/2);df<-n
#   }
#   else{
#     tmp<-sd(x)/sqrt(n)*qt(1-alpha/2,n-1);df<- n-1
#   }
#   data.frame(mean=xb,df=df,a=xb-tmp,b=xb+tmp)
# }
# confint(data1)

#########################################
### End of 3. Prob Dist Function
########################################













########################################################
# 6. Hypothesis Test (통계적 추론방법 (가설검정))
############################################################
rm(list=ls())

########################################################
# p108...모평균에 관한 검정
############################################################
dt <- c(9.2, 12.1, 11.5, 11.0, 10.2, 10.1, 10.4,  8.2,  12.8, 13.4)
t.test(dt, mu=10)

t.test(dt, mu=10, alternative="greater")

# #############################
# ########## Example ##########
# #############################
# #p110
# ? read.csv
# ######### 경로지정 방법 ##############
# #### 방법 1
getwd()
# 
# #### 방법 2
setwd("C:/Users/SDS/Desktop/data/정욱교수님/2_Data_정욱_2019")
# 
# #### 방법 3
# # 파일속성/위치 찾아서 직접 붙이기

data_phone<-read.csv("휴대전화사용료.csv")
fix(data_phone)

t.test(data_phone$AMOUNT,mu=55000,alternative = "greater")

###############################
########## Example ##########
##############################
#p112 
install.packages("EnvStats")
library(EnvStats)

data2<-c(198,201,199,189,200,199,198,189,205,195)
varTest(data2,sigma.squared = 25, alternative = "greater")


# data3<-read.csv("C:/Users/Administrator/Desktop/팝콘무게1.csv", header=F)
# fix(data3)
# class(data3)
# data3<-as.numeric(data3)
# class(data3)
# varTest(data3,sigma.squared = 5)

########################################################
# p116...두 모집단의 모평균 차이에 관한 검정
############################################################
### whours.csv 의 적절한 경로를 지정해야함.... 
whours <- read.csv("whours.csv")
fix(whours)
t.test( hours ~ gender, data=whours, var.equal=TRUE )

########## Example ##################################
#P120
data_sales <-read.csv("salespairs.csv")
fix(data_sales)
t.test( sales ~ status, data=data_sales, paired=TRUE, alternative="less" )

########################################################
# End of 6. Hypothesis Test (통계적 추론방법 (가설검정))
############################################################










########################################################
# 7. Categorical Data Analysis (범주형 자료분석)
############################################################
rm(list=ls())

########################################################
# p127...카이제곱 적합성 검정
########################################################
obs <- c(285, 66, 55, 44)
ms <- c(0.68, 0.13, 0.11, 0.08)
chisq.test(obs, p = ms)

########################################################
# p131...카이제곱 독립성 검정
########################################################
def.table <- cbind( c( 11, 15, 44, 10), 
                    c(25, 31, 24, 17), 
                    c(27, 28, 52, 16) )
def.table
fix(def.table)
chisq.test( def.table )

########################################################
# End of 7. Categorical Data Analysis (범주형 자료분석)
############################################################











########################################################
# 8. ANOVA (분산분석)
############################################################
rm(list=ls())

########################################################
# p136...일원분산분석
############################################################
y1 <- c(15, 11, 12, 13, 12)
y2 <- c(18, 17, 16, 17, 16)
y3 <- c(22, 23, 19, 18, 19)
y <- c(y1, y2, y3)
# y
group <- rep(c("A","B","C"), each=5)
# ?rep # Replicate Elements of Vectors
# group

group_df <- data.frame(y, group)
# group_df
boxplot(y ~ group)

summary( aov(y ~ group, data = group_df) )

# a1<-aov(y ~ group, data = group_df) 
# posthoc <- TukeyHSD(x=a1, conf.level=0.05)
# posthoc

########################################################
# End of 8. ANOVA (분산분석)
############################################################










########################################################
# 9. Regression (상관분석 및 회귀분석)
############################################################
rm(list=ls())

########################################################
# p151...상관분석
#########################################################
twins<- read.csv("twins.csv")
plot( twins$Foster, twins$Biological)
cor.test( twins$Foster, twins$Biological )

########################################################
# p157...단순선형회귀모형 예제
########################################################
data(cars)
head(cars)
plot(cars$speed, cars$dist)

# p161...
m <- lm(dist ~ speed, cars)
m 

# p162
coef( m )

# p163
plot(cars$speed, cars$dist)
abline(coef(m))

# p164
residuals(m)  #잔차
fitted( m ) # 종속변수 추정값  

# p165...
predict(m, 
        newdata=data.frame(speed=c(2,5,3)))

# p170...
summary(m)

# p173...
plot(m, which=1)
plot(m, which=2)

########################################################
# p175...다중선형회귀모형 
########################################################
# p176...
drywall <- read.csv("drywall.csv")
head( drywall )

# p177...
pairs( drywall )

# p179...
lm.fit <- lm( Sales ~ Permits + 
                Mortgage + 
                A.Vacancy + 
                O.Vacancy, 
              data=drywall )
lm.fit 

# p180...
predict.lm ( lm.fit, data.frame( Permits=70, 
                                 Mortgage=6, 
                                 A.Vacancy=4, 
                                 O.Vacancy=12 ))

# p185...
summary( lm.fit )

################################################
######## Example ##############################
###################################################
#p186...
#data(swiss)
str(swiss)
lm.swiss<-lm(Fertility~., data = swiss) # .은 나머지 모든 변수 사용하라는 의미
lm.swiss
summary(lm.swiss)
plot(lm.swiss, which = 1) # 잔차산점도
plot(lm.swiss, which = 2) # QQ plot

# p188...
predict.swiss<-predict(lm.swiss, newdata=data.frame(Agriculture=c(54.1,65.65),Examination=c(12,30.1), Education=c(12,5.4), Catholic=c(50,70.5), Infant.Mortality=c(21.3,19.9)))
predict.swiss

# p189...
# model comparison
model1<-lm(Fertility~Agriculture + Examination + Catholic + Infant.Mortality, data=swiss)
model2<-lm(Fertility~Examination + Education + Infant.Mortality, data=swiss)
model3<-lm(Fertility~Education + Catholic + Infant.Mortality, data=swiss)
summary(model1)
summary(model2)
summary(model3)

########################################################
# p192...다중선형회귀모형 : 다중공선성
########################################################
# p193...
# selling.csv 지정할 필요있음....
house <- read.csv("selling.csv")
summary( lm( price ~ bedrooms + hsize + lotsize, data= house ) )

# p194...
cor( house )

house.fit <-  lm( price ~ bedrooms + hsize + lotsize, data= house ) 

install.packages("car") 
library( car )
vif( house.fit )

# p195...
# Stepwise regression
step( lm( price ~ bedrooms + hsize + lotsize, data= house ) )

# p196...
summary(  lm( price ~ hsize , data= house ) )

########################################################
# End of 9. Regression (상관분석 및 회귀분석)
########################################################

####################################################
####################################################
##########  The End of Total #######################
####################################################
####################################################

