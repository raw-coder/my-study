################################
#################################
## R로 데이터 다루기_전체
#################################
#################################

### 1. 데이터 전처리 개요
### 2. R 다운로드 및 설치
###  Mac computer 사용하는 경우 인코딩
# Sys.setlocale('LC_ALL' , 'ko_KR.UTF-8')


#########################################
### 3. 데이터 다루기를 위한 R 기본함수
###########################################

### head 함수
head(1:50)
tail(1:50)

x = 1:50
x[1:6]

xy = data.frame(x = 1:10, y = 10:1)
head(xy)

### 데이터 차원 알아보기(dim, nrow, ncol)
dim(xy)
nrow(xy)
ncol(xy)

### table 함수
x = c('A', 'B', 'C', 'C', 'A')
table(x)

### nchar과 substr 함수
nchar('a')
nchar('ab')
nchar('20140101')

substr('20140101', 1,4)
substr('20140101', 1,6)
substr('20140101', 5,6)
substr('20140101', 7,8)

### NA(결측치)의 간단한 처리
x = c(1,2,3,NA)
x

is.na(x)
x[is.na(x)]
!is.na(x)
x[!is.na(x)]

xy
xy[2,2] <- NA
xy
xy[!is.na(xy$y), ]


###############################################
### 4. dplyr과 R 기본함수 비교 (체인과 처리속도)
################################################
### 패키지 불러오기
install.packages('dplyr', repos = 'https://cran.seoul.go.kr/')
library(dplyr)

### 1에서 10까지 더하기
1:10
sum(1:10)

1:10 %>% sum

### 데이터 프레임 만들기
df <- data.frame(x=1:10, y=10:1)
df

### 데이터 프레임에서, df에서 x가 5보다 큰 df 필터해서 
### x를 기준으로 내림차순으로 정렬할 뒤에, 
### 이 때 4번 째 행의 y 값을 구해보세요.

###  R기본 방식
df$x > 5
df[df$x > 5, ]
sort(df[df$x > 5, ]$x, decreasing = T)[4]
df[df$x == 7, ]

###  dplyr의 방식
### df   $x>5  sort  4 
df %>% filter(x > 5) %>% arrange(desc(x)) %>% slice(4)

###  R 기본함수로  한줄로…
df[df$x > 5,][order(df[df$x > 5,]$x, decreasing = T)[4],]

### 변수 이름을 바꿀 때, R 기본함수는 모두 다 바꿔주어야 함
xy = df

xy[xy$x > 5,][order(xy[xy$x > 5,]$x, decreasing = T)[4],]
xy %>% filter(x > 5) %>% arrange(desc(x)) %>% slice(4)

### dplyr은 만능이 아니다. 
df + 3
df %>% +3

df  * 3
df %>% *3  ### 에러. 즉 만능 아님

### R 기본함수와 dplyr 속도 비교
install.packages('hflights', repos = 'http://cran.nexr.com')
library(hflights)
library(dplyr)

dim(hflights)
hflights[1:2, ]

### 월별, 도착지별로 도착시간의 평균 구하기
system.time(aggregate(ArrTime ~ Month + Dest, data = hflights, mean))
system.time(hflights %>% group_by(Month, Dest) %>% summarise(meanArr = mean(ArrTime, na.rm=T)))


############################################
### 5. 데이터 들여다보기
############################################
###  Set Working directory로 데이터파일 위치 지정하기
setwd("c:/DMdata")

### 패키지 불러오기
library(dplyr)

### 판매 데이터(sales.csv) 불러오기 및 탐색하기
sales <- read.csv('sales.csv', stringsAsFactors = F,
                  fileEncoding = 'UTF-8')
head(sales)
dim(sales)
colnames(sales)
table(sales$구)

sales %>% select(구) %>% table
sales %>% select(성별, 구) %>% table
sales %>% select(점포명) %>% table
sales %>% select(판매건수) %>% table
sales %>% select(판매건수) %>% summary

### 업종코드(productcode.csv) 불러오기 및 탐색하기
product.code <- read.csv('productcode.csv', stringsAsFactors = F,
                         fileEncoding = "UTF-8")
head(product.code)
product.code %>% head
dim(product.code)
sales %>% head  ### 점포코드에서 앞 4자만 업종코드

### 기후 데이터(seoul_climate.csv) 불러오기 및 탐색하기
climate <- read.csv('seoul_climate.csv', stringsAsFactors = F,
                    fileEncoding = "UTF-8")
head(climate) ## 일별데이터 없음, 강수량에 NA 있음
climate %>% select(연월) %>% table
climate %>% select(강수량) %>% summary


#######################################
### 6. 변수
####################################


####################################################
### 7. 변수 이름 바꾸기 및 새로운 변수 추가하기(mutate)
#####################################################
### 데이터 불러오기
sales <- read.csv('sales.csv', stringsAsFactors = F,
                  fileEncoding = 'UTF-8')

### 변수 이름 바꾸기
head(sales)
colnames(sales)
colnames(sales) <- c('city', 'district', 'gender', 'sales.nm', 'sales.cd', 'ynd', 'sales.num')
colnames(sales)[6] <- 'ymd'
colnames(sales)[c(6,7)] <- c('ymd', 'sales.num')
colnames(sales)
sales %>% head
tbl_df(sales)

### 변수 바꾸기 (mutate 함수)
sales <- sales %>% mutate(city = substr(city,1,2))
sales %>% slice(1:2)

### 새로운 변수 추가하기: 기본함수 사용하기
sales$y <- substr(sales$ymd, 1, 4)
sales$m <- substr(sales$ymd, 5, 6)
sales$d <- substr(sales$ymd, 7, 8)

### 새로운 변수 추가하기: dplyr사용하기
sales <- sales %>% mutate(y = substr(ymd, 1, 4),
                          m = substr(ymd, 5, 6),
                          d = substr(ymd, 7, 8),
                          products.cd = substr(sales.cd, 1, 4))
sales %>% slice(1:2)

### 두 변수 하나로 합치기(연+월=연월)
sales <- sales %>% mutate(ym = paste0(y,m)) 
sales %>% slice(1:2)
sales %>% select(ym) %>% table


##############################################################
### 8. 데이터 정렬(arrage) 및 조건에 맞는 데이터 추출(filter)하기
################################################################

### 변수 이름 확인하기
colnames(sales)

### 판매 건수 기준으로 오름차순으로 정렬하기
sales %>% arrange(sales.num) %>% head

### 판매 건수 기준으로 내림차순으로 정렬하기
sales %>% arrange(desc(sales.num)) %>% head
sales %>% arrange(desc(sales.num)) %>% slice(1:1000)

### 판매 건수 기준으로 내림차순으로 TOP 10을 정렬하여 새로운 변수에 저장하기
sales.top10 <- sales %>% arrange(desc(sales.num)) %>% slice(1:10)
sales.top10

### 성별, 판매 건수 기준으로 오름차순으로 정렬하기
sales %>% arrange(gender, sales.num) %>% slice(1:10)

### 구, 판매 건수 기준으로 내림차순으로 정렬하기
sales %>% arrange(desc(district), desc(sales.num)) %>% slice(1:100)

### 변수 선택하기 및 변수 삭제하기
sales %>% select(y, m) %>% head
sales %>% head
sales.del <- sales %>% select(-ymd)
sales.del %>% head

### 특정 조건에 맞는 데이터 추출하기 (filter 함수)
sales %>% filter(m == '03') %>% head
sales %>% filter(m == '03' & d == '06') %>% head
sales %>% filter(m >= '03') %>% select(m) %>% table
sales %>% select(m) %>% filter(m >= '03') %>% table

### 특정 조건에 맞는 데이터 추출하기 (AND 조건)
sales %>% filter(gender == '남' & gender =='여')

### 특정 조건에 맞는 데이터 추출하기 (OR 조건)
sales %>% filter(gender == '남' | gender =='여') %>% nrow
sales %>% nrow

### 특정 조건에 맞는 데이터 추출하기 (%in% (포함) 조건)
### filter는 등호/부등호,  in은 집합에 포함/불포함
x = 1:10
x %in% c(5,6,7)
x[x %in% c(5,6,7)]

sales %>% head
sales %>% filter(sales.nm %in% c('스탑버스', '카페베타')) %>% head


##########################################################
### 9. 특정 문자가 포함된 데이터 추출하기 (SQL LIKE문)
###########################################################
### 간단한 연습 예제 만들기
library(dplyr)
x <- data.frame(sales.nm = c('스탑버스', '야타버스', '스톱버튼'),
                sales.num = c(1,2,3))
x

### grepl 연습
grepl('스', '스스스')
grepl('스', '가가가')

### 점포명(sales.nm)에서 특정 키워드가 포함된 데이터 추출
x %>% filter(grepl('스', sales.nm))
x %>% filter(grepl('버스', sales.nm))
x %>% filter(grepl('스탑', sales.nm))

### 점포명(sales.nm)에서 특정 키워드로 시작하는 데이터 추출
x %>% filter(grepl('^스', sales.nm))

### 점포명(sales.nm)에서 특정 키워드로 끝나는 데이터 추출
x %>% filter(grepl('스$', sales.nm))

### 실제 데이터 불러오기
sales <- read.csv('sales.csv', stringsAsFactors = F,
                  fileEncoding = 'UTF-8')

sales %>% head
sales %>% select(점포명) %>% unique

### 점포명(sales.nm)에서 특정 키워드가 포함된 데이터 추출
sales %>% filter(grepl('스탑', 점포명)) %>% head

### 점포명(sales.nm)에서 특정 키워드로 시작하는 데이터 추출
sales %>% filter(grepl('^스탑', 점포명)) %>% head

### 점포명(sales.nm)에서 특정 키워드로 끝나는 데이터 추출
sales %>% filter(grepl('스탑$', 점포명)) %>% head


###########################################
### 10. 데이터 요약하기(group_by, summarise)
############################################
### 구별로 판매 건수의 합을 구하세요
colnames(sales) <- c('city', 'district', 'gender', 'sales.nm', 'sales.cd', 'ynd', 'sales.num')
sales %>% 
  group_by(district) %>% 
  summarise(sum.sales.num = sum(sales.num))

### 구별로 판매 건수의 평균을 구하세요
sales %>% 
  group_by(district) %>% 
  summarise(mean.sales.num = mean(sales.num))

### 구별로 판매 건수의 평균을 구하세요, 단 @ 점포는 제거해주세요.
sales %>% 
  group_by(sales.nm) %>%
  summarise(mean.sales.num = mean(sales.num)) %>%
  filter(sales.nm != '@')

sales %>% 
  filter(sales.nm != '@') %>%
  group_by(sales.nm) %>%
  summarise(mean.sales.num = mean(sales.num))

### 성별로 판매 건수의 평균을 구하세요
sales %>% 
  group_by(gender) %>%
  summarise(mean.sales.num = mean(sales.num))

### 성별로 판매 건수의 평균을 구하세요. 단, 성별이 NA인 것은 제외해 주세요.
sales %>% 
  filter(!is.na(gender)) %>%
  group_by(gender) %>%
  summarise(mean.sales.num = mean(sales.num))

### 기후데이터 불러오기 및 변수 이름 바꾸기
climates <- read.csv('seoul_climate.csv', stringsAsFactors = F,
                     fileEncoding = 'UTF-8')
colnames(climates) <- c('city', 'district', 'ym', 'lon', 'lat', 'rainfall')

### 구별로 강수량 평균 구하기
climates %>% 
  group_by(district) %>%
  summarise(sum.rainfall = sum(rainfall, na.rm = T))

### 연월 & 구별로 강수량 평균 구하기
climates %>% 
  group_by(ym, district) %>%
  summarise(sum.rainfall = sum(rainfall, na.rm = T)) %>%
  print(n = 100)


##########################################################
### 11. dplyr 함수들을 조합한 실전 데이터 다루기 1 - 1
##############################################################
### dplyr 불러오기
library(dplyr)

### 데이터(seoul_climate.csv) 불러오기
climates <- read.csv('seoul_climate.csv', stringsAsFactors = F,
                     fileEncoding = 'UTF-8')
colnames(climates) <- c('city', 'district', 'ym', 'lon', 'lat', 'rainfall')


### 문제 01) 6월에서 9월까지, 월별 평균 강수량을 구하세요.
## 생각의 순서 1:  6월에서 9월까지
# 0) nchar(climates$ym) %>% table
# 1) mutate(m = substr(ym, 5, 6))
# 2) filter(m >= '06' & m <= '09')
## 생각의 순서 2:  월별 평균
# 1) group_by(m)
# 2) summarise(mean.rainfall = mean(rainfall, na.rm=T))

climates %>% 
  mutate(m = substr(ym, 5,6)) %>% 
  filter(m >= '06' & m <= '09') %>% 
  group_by(m) %>%
  summarise(mean.rainfall = mean(rainfall, na.rm = T))


### 문제 02) 6월에서 9월까지, 월별 평균 강수량을 구하세요. 내림차순 정렬을 하세요.
#내림차순
# arrange(desc(mean.rainfall))

climates %>% 
  mutate(m = substr(ym, 5,6)) %>%
  filter(m >= '06' & m <= '09') %>% 
  group_by(m) %>%
  summarise(mean.rainfall = mean(rainfall, na.rm=T)) %>%
  arrange(desc(mean.rainfall))


### 문제 03) 6월에서 9월까지, 구별 & 월별 평균 강수량을 구하세요. 내림차순 정렬을 하세요.
climates %>% 
  mutate(m = substr(ym, 5,6)) %>%
  filter(m >= '06' & m <= '09') %>% 
  group_by(district, m) %>%
  summarise(mean.rainfall = mean(rainfall, na.rm=T)) %>%
  arrange(desc(mean.rainfall))


### 문제 04) 6월에서 9월까지, 구별 & 월별 평균 강수량을 구하세요. 전체에서 내림차순 정렬을 하세요.
climates %>% 
  mutate(m = substr(ym, 5,6)) %>%
  filter(m >= '06' & m <= '09') %>% 
  group_by(district, m) %>%
  summarise(mean.rainfall = mean(rainfall, na.rm=T)) %>%
  ungroup %>% 
  arrange(desc(mean.rainfall))


### 문제 05) 2014년 12월에서 가장 비가 많이 온 날과 
### 2015년 9월에서 가장 비가 많이 온 지역을 출력해보세요.
climates %>% 
  filter(ym == '201412') %>% 
  arrange(desc(rainfall)) %>% 
  slice(1)

climates %>%
  filter(ym == '201412') %>% 
  group_by(ym) %>%
  summarise(max.rainfall = max(rainfall, na.rm = T)) 
climates %>% filter(rainfall == 276)

climates %>% 
  filter(ym == '201509') %>% 
  arrange(desc(rainfall)) %>% 
  slice(1) %>%
  select(district)


### 문제 06) 구별 평균 강수량을 구하되, 내림차순으로 순위를 매기시오.
rank(c(30, 20, 10, 40, 50))
rank(c(30, 20, 10, 10, 50))
rank(c(30, 20, 10, 10, 50), ties.method = 'average')
rank(c(30, 20, 10, 10, 50), ties.method = 'min')
rank(c(30, 20, 10, 10, 50), ties.method = 'first')
## 생각의 순서
# 1) group_by(district)
# 2) summarise(mean(rainfall, na.rm = T))
# 3) mean.ranfall * -1   # 내림차순
rank(-1*c(30, 20, 10, 10, 50), ties.method = 'min')
# 4) arrange

climates %>% 
  group_by(district) %>%
  summarise(mean.rainfall = mean(rainfall, na.rm = T)) %>%
  mutate(rank = rank(-mean.rainfall, ties.method = 'min')) %>%
  arrange(rank)


### 문제 07) 문제 06)의 결과에서 송파구, 강남구, 중랑구만 선택하여, 
### 다시 평균 강수량의 내림차순으로 재정렬하세요.
## 생각의 순서
# 1) filter(변수 %in% 관심값)

climates %>% 
  group_by(district) %>%
  summarise(mean.rainfall = mean(rainfall, na.rm = T)) %>%
  filter(district %in% c('송파구', '강남구', '중랑구')) %>%
  arrange(desc(mean.rainfall))

climates %>% 
  group_by(district) %>%
  summarise(mean.rainfall = mean(rainfall, na.rm = T)) %>%
  mutate(rank = rank(-mean.rainfall, ties.method = 'min')) %>%
  arrange(rank) %>%
  filter(district %in% c('송파구', '강남구', '중랑구')) %>%
  arrange(rank)


#####################################################
### 12. dplyr 함수들을 조합한 실전 데이터 다루기 1 - 2
########################################################
### 데이터 탐색하기
climates %>% head


### 문제 08) 지역구별 & 년도별 강수량 합계를 구하시오.
## 생각의 순서
# 1) mutate(y = substr(ym, 1, 4))
# 2) group_by(district, y)
# 3) summarise(sum.rainfall = sum(rainfall, na.rm = T ))

climates %>%
  mutate(y = substr(ym, 1, 4)) %>%
  group_by(district, y) %>%
  summarise(sum.rainfall = sum(rainfall, na.rm = T))


### 문제 09) 서울지역 위도(latitude)와 경도(longitude)의 평균을 구하시오. (난이도 중)
climates %>% 
  summarise(mean.lon = mean(lon), mean.lat = mean(lat))

## 혹시 구마다 개수가 다르지 않을까?
climates %>% 
  select(district) %>%
  table
climates %>% select(district) %>% nrow

## 구마다 중복을 피하여 하나씩 고려하여 총 구의 개수를 구하자.
climates %>% distinct(district) %>% select(district) %>% nrow

## 서울의 강남구, 대구의 강남구를 따로 구분하여야 한다면…
climates %>% distinct(city, district, lon, lat) %>% select(district) %>% nrow
climates %>% 
  distinct(city, district, lon, lat) %>%
  summarise(mean.lon = mean(lon), mean.lat = mean(lat))


### 문제 10) 강수량 데이터에서 250mm 이상은 상, 50mm ~ 250mm는 중, 50mm 미만은 하로 변환해 보세요.
## 생각의 순서
# mutate(ifelse(rainfall >= 250, '상', ifelse(rainfall >= 50, '중', '하')))

climates %>% 
  mutate(rainfall.grade = ifelse(rainfall >= 250, '상', ifelse(rainfall >= 50, '중', '하'))) %>%
  select(district, rainfall.grade) %>% 
  table

climates %>% 
  mutate(rainfall.grade = ifelse(rainfall >= 250, '상', ifelse(rainfall >= 50, '중', '하'))) %>%
  select(ym, rainfall.grade) %>% 
  table


### 문제 11) 지역별로 강수량이 누락된 연월을 표시해주세요.
## 생각의 순서
# group_by
# filter(is.na(rainfall))

climates %>% 
  group_by(district) %>%
  filter(is.na(rainfall)) %>% 
  select(district, ym) %>% nrow

climates %>% 
  group_by(district) %>%
  filter(is.na(rainfall)) %>% 
  select(district, ym) %>% 
  print(n=103)


###################################################
### 13. dplyr 함수들을 조합한 실전 데이터 다루기 2 - 1
####################################################

### dplyr라이브러리 불러오기
library(dplyr)

### 데이터(sales.csv) 불러오기
## Set Working directory
# setwd('C:/DMdata')

sales <- read.csv('sales.csv', stringsAsFactors = F,
                  fileEncoding = 'UTF-8')
colnames(sales) <- c('city', 'district', 'gender', 'sales.nm', 'sales.cd', 'ymd', 'sales.num')


### 문제01) 판매건수를 기준으로 WORST 10개를 출력해주세요.
sales %>%
  arrange(sales.num) %>%
  slice(1:10)


### 문제02) 남자 중 판매건수를 기준으로 BEST 10개를 추출해보세요.
## 생각의 순서
# filter
# arrange(desc(sales.num))
# slice(1:10)

sales %>% 
  filter(gender == '남') %>%
  arrange(desc(sales.num)) %>%
  slice(1:10)


### 문제03) 여자 & 강남구에서 판매건수를 기준으로 BEST 10개를 추출해보세요.
sales %>% 
  filter(gender == '여' & district == '강남구') %>%
  arrange(desc(sales.num)) %>%
  slice(1:10)


### 문제04-1) 여자 중에서 지역구별로 가장 많이 판매되는 업종 1개를 추출하세요.
## 생각의 순서
# filter(gender == ‘여’)
# group_by(district, sales.nm)
# summarise(sum.sales.num = sum(sales.num, na.rm =T))
# arrange(desc(sum.sales.num))
# slice(1:3)

sales %>%
  filter(gender == '여') %>%
  group_by(district, sales.nm) %>%
  summarise(sum.sales.num = sum(sales.num, na.rm =T)) %>%
  arrange(desc(sum.sales.num)) %>%
  slice(1)


### 문제04-2) 여자 중에서 지역구별로 가장 많이 판매되는 업종 3개를 추출하고, 구별로 판매건수 합의 평균을 구하세요.
sales %>%
  filter(gender == '여') %>%
  group_by(district, sales.nm) %>%
  summarise(sum.sales.num = sum(sales.num, na.rm =T)) %>%
  arrange(desc(sum.sales.num)) %>%
  slice(1:3) %>% 
  group_by(district) %>%
  summarise(mean.sales.num = mean(sum.sales.num, na.rm = T))


### 문제05) 강남구에서 판매건수를 기준으로 BEST 50개를 출력하는데, 순위도 매겨주세요.
sales %>% 
  filter(district == '강남구') %>%
  arrange(desc(sales.num)) %>%
  slice(1:50) %>%
  mutate(rank = rank(-sales.num, ties.method = 'min'))


########################################################
### 14. dplyr 함수들을 조합한 실전 데이터 다루기 2 - 2
########################################################
### 문제06) 구별 판매건수의 합을 남녀 별로 비교해주세요.
## 생각의 순서
# group_by()
# summarise(sum)

sales %>% 
  group_by(district, gender) %>%
  summarise(sum.sales.num = sum(sales.num, na.rm = T))

sales %>% 
  filter(!is.na(gender)) %>%
  group_by(district, gender) %>%
  summarise(sum.sales.num = sum(sales.num, na.rm = T))


### 문제07) 강남구에서 월별 판매건수의 합을 남녀 별로 비교해주세요.
sales %>% 
  filter(district == '강남구') %>%
  mutate(m = substr(ymd, 5, 6)) %>%
  group_by(m, gender) %>%
  summarise(sum.sales.num = sum(sales.num, na.rm = T))

sales %>% 
  filter(district == '강남구' & !is.na(gender)) %>%
  mutate(m = substr(ymd, 5, 6)) %>%
  group_by(m, gender) %>%
  summarise(sum.sales.num = sum(sales.num, na.rm = T))


### 문제08) 관악구와 강남구에서 구별로 일별 판매건수가 가장 큰 점포와 해당 날짜를 추출하세요
sales %>% 
  filter(district %in% c('관악구', '강남구')) %>%
  group_by(district) %>%
  arrange(desc(sales.num)) %>%
  slice(1)

## 함정1) 성별에 관계없이 일별 판매건수 합을 구해야…
sales %>%
  filter(district %in% c('관악구', '강남구')) %>%
  group_by(district, sales.nm, ymd) %>%
  summarise(sum.sales.num = sum(sales.num, na.rm = T)) %>%
  group_by(district) %>%
  arrange(desc(sum.sales.num)) %>%
  slice(1)

## 함정2) 동률이 있을 수 있다
sales %>%
  filter(district %in% c('관악구', '강남구')) %>%
  group_by(district, sales.nm, ymd) %>%
  summarise(sum.sales.num = sum(sales.num, na.rm = T)) %>%
  group_by(district) %>%
  mutate(rank = rank(-sum.sales.num, ties.method = 'min')) %>%
  filter(rank == 1) %>%
  print(n = 100)


### 문제09-1) 일별 평균 판매건수를 성별로 비교해보세요. 
sales %>% 
  group_by(gender) %>%
  summarise(mean.sales.num = mean(sales.num, na.rm =T))


### 문제09-2) 일별 판매건수를 구, 연월일, 성별을 고려하여 최댓값을 만들고, 즉, 점포명을 무시하고 이 최댓값의 평균을 성별로 비교해보세요. (난이도 중)
sales %>%
  group_by(district, ymd, gender) %>%
  summarise(max.sales.num = max(sales.num, na.rm = T)) %>%
  group_by(gender) %>%
  summarise(mean.sales.num = mean(max.sales.num, na.rm = T))


### 문제10) 판매건수를 기준으로 2014년 중 지역별 & 점포별로(### 성별 등은 무시하고 평균값을 구해 내림차순 정렬하되, 
### 지역별 & 점포별로 TOP 2개만 뽑아주세요. 
### 단, @ 점포는 제외하시오
sales %>% filter(sales.nm != '@') %>%
  mutate(y = substr(ymd, 1, 4)) %>%
  filter(y == '2014') %>%
  group_by(district, sales.nm) %>%
  summarise(mean.sales.num = mean(sales.num, na.rm =T)) %>%
  arrange(desc(mean.sales.num)) %>%
  slice(1:2)

sales %>% filter(sales.nm != '@') %>%
  mutate(y = substr(ymd, 1, 4)) %>%
  filter(y == '2014') %>%
  group_by(y, district, sales.nm) %>%
  summarise(mean.sales.num = mean(sales.num, na.rm =T)) %>%
  arrange(desc(mean.sales.num)) %>%
  slice(1:2) %>%
  print(n = 100)


###################################
### 15. 다른 데이터 합치기(join)
####################################
### 예제 데이터 생성
df1 <- data.frame(title = c('카페', '한식', '유아용품', '양식', '전자제품'),
                  last_rank = c(1,2,3,4,5))
df2 <- data.frame(title = c('한식', '양식', '전자제품', '일식', '꽃'),
                  this_rank = c(1,2,3,4,5))
df1
df2


### 다양한 조인 연습해보기
library(dplyr)
left_join(df1, df2, by='title')
left_join(df1, df2)
right_join(df1, df2, by='title')
left_join(df2, df1, by='title')
inner_join(df1, df2, by='title')
anti_join(df1, df2, by='title')
full_join(df1,df2, by='title')

### 실제 데이터(sales.csv, productcode.csv, seoul_climate.csv) 불러오기
sales <- read.csv('sales.csv', stringsAsFactors = F,
                  fileEncoding = 'UTF-8')
colnames(sales) <- c('city', 'district', 'gender', 'sales.nm', 'sales.cd', 'ymd', 'sales.num')

products <- read.csv("productcode.csv", stringsAsFactors = F,
                     fileEncoding = "UTF-8")
colnames(products) <- c('products.cd', 'products.nm')

climates <- read.csv('seoul_climate.csv', stringsAsFactors = F,
                     fileEncoding = 'UTF-8')
colnames(climates) <- c('city', 'district', 'ym', 'lon', 'lat', 'rainfall')


### 판매데이터와 업종코드 데이터를 결합하기
sales %>% head
products %>% head

sales <- sales %>% mutate(products.cd = substr(sales.cd, 1, 4))
sales <- left_join(sales, products, by = 'products.cd')
sales %>% head


### 판매 데이터와 기후 데이터 결합하기
climates %>% head
sales %>% head
sales <- sales %>% mutate(ym = substr(ymd, 1, 6))  # character로 인식
sales <- left_join(sales, climates)  # 오류 발생(앞은 character, 뒤는 integer)
str(sales)    # structure
str(climates)

climates$ym <- as.character(climates$ym)
sales <- left_join(sales, climates)  # by= 생략시에는 모든 공통 변수 사용

sales %>% head
sales %>% filter(!is.na(rainfall)) %>% head

climates %>% head


####################################################
### 16. dplyr 함수들을 조합한 실전 데이터 다루기 3
########################################################
### 실제 데이터(sales.csv, productcode.csv, seoul_climate.csv) 불러오기
sales <- read.csv('sales.csv', stringsAsFactors = F,
                  fileEncoding = 'UTF-8')
colnames(sales) <- c('city', 'district', 'gender', 'sales.nm', 'sales.cd', 'ymd', 'sales.num')

products <- read.csv("productcode.csv", stringsAsFactors = F,
                     fileEncoding = "UTF-8")
colnames(products) <- c('products.cd', 'products.nm')

climates <- read.csv('seoul_climate.csv', stringsAsFactors = F,
                     fileEncoding = 'UTF-8')
colnames(climates) <- c('city', 'district', 'ym', 'lat', 'lon', 'rainfall')

sales %>% head
products %>% head



### 데이터 합치기 (# 전에 이미 수행함)
sales <- sales %>% 
  mutate(products.cd = substr(sales.cd, 1, 4))
sales <- left_join(sales, products)
sales %>% head

sales <- sales %>% 
  mutate(ym = substr(ymd, 1, 6))
climates$ym <- as.character(climates$ym)
sales <- left_join(sales, climates)
sales %>% head


### Q1. 업종별(products.nm) 평균 판매건수를 구하세요. 
### 단, NA 업종은 제외하세요.
sales %>%
  filter(!is.na(products.nm)) %>%
  group_by(products.nm) %>%
  summarise(mean.sales.num = mean(sales.num, na.rm = T))


### Q2. 한식 업종의 월별 평균 판매건수를 구하고, 
### 내림차순으로 정렬을 하세요.
sales %>%
  filter(products.nm == '한식') %>%
  mutate(m = substr(ymd, 5, 6)) %>%
  group_by(products.nm, m) %>%
  summarise(mean.sales.num = mean(sales.num, na.rm = T)) %>%
  arrange(desc(mean.sales.num))


### Q3. 매출데이터에서 월별 & 구별 & 업종(products.nm)별 
### 평균 판매 건수와 평균 강수량을 구하세요. 
### 단, 평균 판매 건수와 평균 강수량이 NA인 것은 제외하세요.
sales %>%
  mutate(m = substr(ymd, 5, 6)) %>%
  group_by(m, district, products.nm) %>%
  summarise(mean.sales.num = mean(sales.num, na.rm = T),
            mean.rainfall = mean(rainfall, na.rm = T)) %>%
  filter(!is.na(mean.sales.num) & !is.na(mean.rainfall))


### Q4. Q3의 결과에서 평균 강수량(mean.rainfall)을 
### 250 이상은 '상', 50 ~ 250은 '중', 50미만은 '하'로 바꾸어 
### 새로운 변수에 저장하세요.
sales %>%
  mutate(m = substr(ymd, 5, 6)) %>%
  group_by(m, district, products.nm) %>%
  summarise(mean.sales.num = mean(sales.num, na.rm = T),
            mean.rainfall = mean(rainfall, na.rm = T)) %>%
  filter(!is.na(mean.sales.num) & !is.na(mean.rainfall)) %>%
  mutate(rainfall.grade = ifelse(mean.rainfall >= 250, '상', 
                                 ifelse(mean.rainfall >= 50, '중', '하'))) %>%
  View   #V는 대문자


### Q5. 위 Q4의 결과에서 평균 강수량 등급(rainfall.grade) 별 평균 판매건수(mean.sales.num)의 평균을 다시 구해보세요.
sales %>%
  mutate(m = substr(ymd, 5, 6)) %>%
  group_by(m, district, products.nm) %>%
  summarise(mean.sales.num = mean(sales.num, na.rm = T),
            mean.rainfall = mean(rainfall, na.rm = T)) %>%
  filter(!is.na(mean.sales.num) & !is.na(mean.rainfall)) %>%
  mutate(rainfall.grade = ifelse(mean.rainfall >= 250, '상', 
                                 ifelse(mean.rainfall >= 50, '중', '하'))) %>%
  group_by(rainfall.grade) %>%
  summarise(mean.mean.sales.num = mean(mean.sales.num, na.rm = T))


### 작업이 복잡하거나 연습을 위해서는 
### 중간에 한 번 데이터를 새로운 변수로 저장하고, 
### 그 이후에 이어서 작업을 하는 것이 긴 체인을 피하는 방법입니다. 
mean.sales <- sales %>%
  mutate(m = substr(ymd, 5, 6)) %>%
  group_by(m, district, products.nm) %>%
  summarise(mean.sales.num = mean(sales.num, na.rm = T),
            mean.rainfall = mean(rainfall, na.rm = T)) %>%
  filter(!is.na(mean.sales.num) & !is.na(mean.rainfall))

mean.sales %>% 
  mutate(rainfall.grade = ifelse(mean.rainfall >= 250, '상', 
                                 ifelse(mean.rainfall >= 50, '중', '하'))) %>%
  group_by(rainfall.grade) %>%
  summarise(mean.mean.sales.num = mean(mean.sales.num, na.rm = T))


####################################################
### 17. dplyr 결과를 파일로 저장하기
######################################################
### write.csv를 이용하여 파일 저장하기
write.csv(sales, 'res.csv')
res.new <- read.csv('res.csv', stringsAsFactors = F)
res.new  # 행번호 포함


### write.table을 이용하여 행번호 없이 파일 저장하기(write.table)
write.table(sales, 'res.csv', row.names = F, sep = ',')
res.new <- read.csv('res.csv', stringsAsFactors = F)
res.new



################################
### The End
################################
