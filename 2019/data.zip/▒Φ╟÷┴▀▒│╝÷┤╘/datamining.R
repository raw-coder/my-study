### Regression ###
setwd("c:/DMdata")
usedcar2 <- read.csv("usedcar2.csv",header = T)
head(usedcar2)
summary(usedcar2)
# mean values for each color
mean(usedcar2$Price)
mean(usedcar2$Price[usedcar2$Color=='white'])
mean(usedcar2$Price[usedcar2$Color=='silver'])
mean(usedcar2$Price[usedcar2$Color=='other'])
# or using dplyr package
library(dplyr)
usedcar2 %>% summarise(mean(Price))
usedcar2 %>% group_by(Color) %>% summarise(mean(Price))
# indicator variables
usedcar2$Ind1<-as.numeric(usedcar2$Color == 'white')
usedcar2$Ind2<-as.numeric(usedcar2$Color == 'silver')
head(usedcar2,10)
# regression fitting
lm_used<-lm(Price ~ Odometer + Ind1 + Ind2, data=usedcar2)
summary(lm_used)
round(coef(lm_used),4)
# mean odometer for each color
usedcar2 %>% group_by(Color) %>% summarise(mean(Odometer))
# plotting
attach(usedcar2)
plot(Price~Odometer,col=ifelse(Color=='silver','black',ifelse(Color=='white','blue','red')))
lines(x <- c(19000,49300), y=16700.6-0.0555*x, lty=3)    
text(32000, 14500, "y=16700.6-0.0555*x")
lines(x <- c(19000,49300), y=16791.1-0.0555*x, lty=2)    
text(40000, 14800, "y=16791.1-0.0555*x")
lines(x <- c(19000,49300), y=16996.1-0.0555*x, lty=1)    
text(31000, 15500, "y=16996.1-0.0555*x")
detach(usedcar2)
# regression diagnostics
plot(lm_used,which=2)
plot(lm_used,which=1)



### Logistic Regression ###
# Buytest Data
setwd("C:/DMdata")
buytest = read.table('buytest.txt',sep='\t',header=T)
head(buytest[,c("AGE","BUY18","CLIMATE","FICO","INCOME","MARRIED","OWNHOME","SEX")],15)
complete=complete.cases(buytest[,c("RESPOND","AGE","BUY18","CLIMATE","FICO","INCOME","MARRIED","OWNHOME","SEX")])
buytest1<-buytest[complete,c("RESPOND","AGE","BUY18","CLIMATE","FICO","INCOME","MARRIED","OWNHOME","SEX")]
# fitting full model
full_model = glm(RESPOND~AGE+BUY18+CLIMATE+FICO+INCOME+MARRIED+OWNHOME+SEX,
             family="binomial",data=buytest1)
summary(full_model)
# model's significance
empty_model = glm(RESPOND~1, family="binomial", data=buytest1)
anova(full_model, empty_model, test="Chisq")
# variable selection
step_model = step(full_model, direction='both') # direction='backward' is default
summary(step_model)
# predicted probability
smith = data.frame(AGE=35,BUY18=1,CLIMATE=15,FICO=800,MARRIED=1,OWNHOME=0)
predict(step_model, newdata=smith, type='response')
table(buytest1$RESPOND)
table(buytest1$RESPOND)/nrow(buytest1)
# odds ratio
exp(coef(step_model)) 



### K nearest neighbor ###
# Buytest Data
install.packages("class",repos="http://healthstat.snu.ac.kr/CRAN/")
library(class)
setwd("C:/DMdata")
buytest = read.table('buytest.txt',sep='\t',header=T)
buytest$SEX<-as.numeric(buytest$SEX=='F')
complete=complete.cases(buytest[,c("RESPOND","AGE","BUY18","CLIMATE","FICO","INCOME","MARRIED","OWNHOME","SEX")])
buytest1.x<-buytest[complete,c("AGE","BUY18","CLIMATE","FICO","INCOME","MARRIED","OWNHOME","SEX")]
buytest1.y<-buytest[complete,c("RESPOND")]
smith = data.frame(AGE=35,BUY18=1,CLIMATE=15,FICO=800,INCOME=50,MARRIED=1,OWNHOME=0,SEX=1)   
knn(train=buytest1.x, test=smith, cl=buytest1.y, k = 100, prob = T)



### Naive Bayes ###
# Buytest Data
install.packages("e1071",repos="http://healthstat.snu.ac.kr/CRAN/")
library(e1071)
setwd("C:/DMdata")
buytest = read.table('buytest.txt',sep='\t',header=T)
complete=complete.cases(buytest[,c("RESPOND","AGE","BUY18","CLIMATE","FICO","INCOME","MARRIED","OWNHOME","SEX")])
buytest1<-buytest[complete,c("RESPOND","AGE","BUY18","CLIMATE","FICO","INCOME","MARRIED","OWNHOME","SEX")]
smith = data.frame(AGE=35,BUY18=1,CLIMATE=15,FICO=800,INCOME=50,MARRIED=1,OWNHOME=0,SEX='F') 
nb_model <- naiveBayes(RESPOND~AGE+BUY18+CLIMATE+FICO+INCOME+MARRIED+OWNHOME+SEX, data = buytest1)
nb_model
predict(nb_model, smith, type='raw')



### Model Evaluation ###
# Fitting by training data and validating by test data
setwd("C:/DMdata")
buytest = read.table('buytest.txt',sep='\t',header=T)
complete=complete.cases(buytest[,c("RESPOND","AGE","BUY18","CLIMATE","FICO","MARRIED","OWNHOME")])
buytest1<-buytest[complete,c("RESPOND","AGE","BUY18","CLIMATE","FICO","MARRIED","OWNHOME")]
nobs=nrow(buytest1)
# training and test data
set.seed(1234)
i = sample(1:nobs, round(nobs*0.7)) #70% for training data, 30% for testdata
train = buytest1[i,] 
test = buytest1[-i,]
nrow(train);nrow(test)
# several models
model1 = glm(RESPOND~AGE+BUY18+CLIMATE+FICO+MARRIED+OWNHOME,family="binomial", data=train)
model2 = glm(RESPOND~AGE+BUY18+CLIMATE+FICO,family="binomial", data=train)
model3 = naiveBayes(RESPOND~AGE+BUY18+CLIMATE+FICO+MARRIED+OWNHOME, data=train)
# predicted probability
prob_pred1 = predict(model1, newdata=test, type='response')
prob_pred2 = predict(model2, newdata=test, type='response')
prob_pred3 = predict(model3, newdata=test, type='raw')[,2]
pred_knn = knn(train=train[,-1], test=test[,-1], cl=train[,1], k = 101, prob = T)
prob_pred4 = 1-attr(pred_knn,"prob") 

y_pred1 = as.numeric(prob_pred1 > 0.075)
tab1=table(test$RESPOND, y_pred1)
print(tab1)
sum(diag(tab1))/sum(tab1)
y_pred2 = as.numeric(prob_pred2 > 0.075)
tab2=table(test$RESPOND, y_pred2)
print(tab2)
sum(diag(tab2))/sum(tab2)
y_pred3 = as.numeric(prob_pred3 > 0.075)
tab3=table(test$RESPOND, y_pred3)
print(tab3)
sum(diag(tab3))/sum(tab3)
y_pred4 = as.numeric(prob_pred4 > 0.075)
tab4=table(test$RESPOND, y_pred4)
print(tab4)
sum(diag(tab4))/sum(tab4)

# ROC curve
install.packages("pROC",repos="http://healthstat.snu.ac.kr/CRAN/")
library(pROC)
roccurve1 <- roc(test$RESPOND ~ prob_pred1)
roccurve2 <- roc(test$RESPOND ~ prob_pred2)
roccurve3 <- roc(test$RESPOND ~ prob_pred3)
roccurve4 <- roc(test$RESPOND ~ prob_pred4)
plot(roccurve1, col="red", print.auc=TRUE, print.auc.adj=c(2.5,-8), auc.polygon=TRUE)
plot(roccurve2, col="blue", add=TRUE,  print.auc=TRUE, print.auc.adj=c(-1,-8))
plot(roccurve3, col="black", add=TRUE, print.auc=TRUE, print.auc.adj=c(2.5,-4))
plot(roccurve4, col="green", add=TRUE,  print.auc=TRUE, print.auc.adj=c(-1,-4))
legend("bottomright", legend=c("stepwise","simple","naivebayes","KNN"), 
       col=c("red","blue","black","green"), lwd=2)



### Decision Trees ###
# hmeq data
setwd("c:/DMdata")
hmeq<-read.table("hmeq.txt",header=T,sep='\t')
head(hmeq,10)
levels(hmeq$REASON)[levels(hmeq$REASON)==""]<-NA
levels(hmeq$JOB)[levels(hmeq$JOB)==""]<-NA
# training and test data
set.seed(1234)
nobs=nrow(hmeq)
i = sample(1:nobs, round(nobs*0.6)) #60% for training data, 40% for test data
train = hmeq[i,] 
test = hmeq[-i,]
nrow(train);nrow(test)
# default tree
library(rpart)
install.packages("rpart.plot",repos="http://healthstat.snu.ac.kr/CRAN/")
library(rpart.plot)
tree0 <- rpart(BAD ~ ., data = train, method="class")
prp(tree0, type=4, extra=2, digits=3)
# maximal tree
set.seed(1234)
my.control <- rpart.control(xval=10, cp=0.001)
tree1 <- rpart(BAD ~ ., data = train, method="class", control=my.control)
plot(tree1, uniform=T, compress=T, margin=0.05)
# pruning
printcp(tree1)
plotcp(tree1)
tree1.prun <- prune(tree1, cp = 0.0045)
print(tree1.prun)
prp(tree1.prun, type=4, extra=2, digits=3)
#stunting
my.control <- rpart.control(xval=0, cp=0.01, minsplit=100)
tree2 <- rpart(BAD ~ ., data = train, method="class", control=my.control)
prp(tree2, type=4, extra=2, digits=3)
# comparison of trees
prob0 <- predict(tree0, newdata=test, type="prob") 
prob1 <- predict(tree1.prun, newdata=test, type="prob") 
prob2 <- predict(tree2, newdata=test, type="prob") 
# type="prob" for class probability, type="vector" for regression
library(pROC)
roccurve0 <- roc(test$BAD ~ prob0[,2])
roccurve1 <- roc(test$BAD ~ prob1[,2])
roccurve2 <- roc(test$BAD ~ prob2[,2])
plot(roccurve1, col="red", print.auc=TRUE, print.auc.adj=c(2.5,-8), auc.polygon=TRUE)
plot(roccurve2, col="blue", add=TRUE,  print.auc=TRUE, print.auc.adj=c(-1,-8))
plot(roccurve0, col="green", add=TRUE,  print.auc=TRUE, print.auc.adj=c(-1,-5))
legend("bottomright", legend=c("pruning", "stunting","default"), col=c("red", "blue","green"), lwd=2)



### Hierarchical Clustering
head(USArrests)
zUSArrests=scale(USArrests)
summary(zUSArrests)
hc1=hclust(dist(zUSArrests),method="average")
plot(hc1, hang = -1)
rect.hclust(hc1, k=5)
cutree(hc1, k=5)
USArrests$cluster <- cutree(hc1, k=5)
library(dplyr)
USArrests %>% group_by(cluster) %>% 
  summarise(mean_Murder=mean(Murder), mean_Assault=mean(Assault), mean_Rape=mean(Rape))



### K-means Clustering
# Dungaree Data
setwd("C:/DMdata")
dungaree = read.table('dungaree.csv',sep=',',header=T)
head(dungaree,10)
tail(dungaree,3)
## transformation
library(dplyr)
dungaree <- dungaree %>% 
  mutate(fratio=log(fashion/original), lratio = log(leisure/original), sratio = log(stretch/original))
dungratio = dungaree[,c("fratio", "lratio", "sratio")]
summary(dungratio)
zdungratio = scale(dungratio)
summary(zdungratio)
# 3D plot
install.packages("rgl",repos="http://healthstat.snu.ac.kr/CRAN/")
install.packages("httpuv",repos="http://healthstat.snu.ac.kr/CRAN/")
library(rgl)
plot3d(zdungratio[,1], zdungratio[,2], zdungratio[,3], col="blue", size=5) 
# hierarchical clustering
hc_dung=hclust(dist(zdungratio), method="average")
plot(hc_dung, hang = -1)
rect.hclust(hc_dung, k=3)
# initial points
tmp <- data.frame(zdungratio)
tmp$cluster <- cutree(hc_dung, k=3)
library(dplyr)
tmp %>% group_by(cluster) %>% 
  summarise(mean_fratio=mean(fratio), mean_lratio=mean(lratio), mean_sratio=mean(sratio))
x1 <- c(0,0,-6)
x2 <- c(0,0,0)
x3 <- c(0,-3,0)
kcenters <- data.frame(x1,x2,x3)
# K-means clustering
kmean_dung = kmeans(zdungratio,centers=kcenters)
kmean_dung
pairs(zdungratio, col=kmean_dung$cluster, pch=16)



### Association Rule
install.packages("arules",repos="http://healthstat.snu.ac.kr/CRAN/")
library(arules)
# dvdtrans data
setwd("C:/DMdata")
dvd.trans= read.transactions("dvdtrans.csv", format="single", sep=",", cols=c("ID","Item"))
summary(dvd.trans)
image(dvd.trans)
# finding association rule
dvd.rules <- apriori(dvd.trans) 
summary(dvd.rules)
inspect(head(sort(dvd.rules, by ="lift"),10))
# parameter tuning
dvd.nrules <- apriori(dvd.trans, parameter = list(supp = 0.2, conf = 0.8, maxlen=4))
summary(dvd.nrules)
inspect(sort(dvd.nrules, by ="lift"))
# plotting the rules
install.packages("arulesViz",repos="http://healthstat.snu.ac.kr/CRAN/")
library(arulesViz)
plot(dvd.nrules, method="graph")
write(dvd.nrules, file = "rules.csv", sep = ",", col.names = NA)

# grocery data
setwd("C:/DMdata")
grocery= read.transactions("grocery.csv", format="basket", sep=",")
summary(grocery)
grocery.rules=apriori(grocery)
grocery.rules <- apriori(grocery, parameter = list(supp = 0.05, conf = 0.1, minlen=2))
inspect(head(sort(grocery.rules, by ="lift"),10))
library(arulesViz)
plot(grocery.rules, method="graph")

# Building
setwd("C:/DMdata")
build <- read.csv("building.csv" , header = T)
build <- build[,-1]
build 
trans <- as.matrix(build , "Transaction")
rules1 <- apriori(trans , parameter = list(supp=0.2 , conf = 0.6))
inspect(sort(rules1, by ="lift"))
plot(rules1, method="graph")
rules2 <- subset(rules1 , subset = lhs %pin% '학원' & confidence > 0.7)
inspect(sort(rules2)) 
rules3 <- subset(rules1 , subset = rhs %pin% '편의점' & confidence > 0.7)
inspect(sort(rules3)) 
b2 <- t(as.matrix(build)) %*% as.matrix(build) 
b2
b2.w <- b2 - diag(diag(b2))
b2.w
install.packages("sna",repos="http://healthstat.snu.ac.kr/CRAN/")
library(sna)
gplot(b2.w, displaylabel=T, vertex.cex=sqrt(diag(b2)), arrowhead.cex=0, edge.lwd = b2.w*2)

